package com.proyecto.clases;

public enum ResultadoEnum {
    ganador, perdedor, empate;
}
